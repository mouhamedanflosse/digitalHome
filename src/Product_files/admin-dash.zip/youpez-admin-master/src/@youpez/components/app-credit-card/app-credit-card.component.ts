import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'youpez-credit-card',
  templateUrl: './app-credit-card.component.html',
  styleUrls: ['./app-credit-card.component.scss']
})
export class AppCreditCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
