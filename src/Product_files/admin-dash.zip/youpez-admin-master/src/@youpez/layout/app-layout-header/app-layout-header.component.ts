import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-layout-header',
  templateUrl: './app-layout-header.component.html',
  styleUrls: ['./app-layout-header.component.scss']
})
export class AppLayoutHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
