import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-layout-divided-alt',
  templateUrl: './app-layout-divided-alt.component.html',
  styleUrls: ['./app-layout-divided-alt.component.scss']
})
export class AppLayoutDividedAltComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
