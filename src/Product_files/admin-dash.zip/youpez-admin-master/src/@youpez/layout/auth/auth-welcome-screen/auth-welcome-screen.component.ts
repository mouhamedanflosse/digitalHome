import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'youpez-auth-welcome-screen',
  templateUrl: './auth-welcome-screen.component.html',
  styleUrls: ['./auth-welcome-screen.component.scss']
})
export class AuthWelcomeScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
