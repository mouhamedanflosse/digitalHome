import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-layout-horizontal',
  templateUrl: './app-layout-horizontal.component.html',
  styleUrls: ['./app-layout-horizontal.component.scss']
})
export class AppLayoutHorizontalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
