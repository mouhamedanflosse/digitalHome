import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms-general',
  templateUrl: './forms-general.component.html',
  styleUrls: ['./forms-general.component.css']
})
export class FormsGeneralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
