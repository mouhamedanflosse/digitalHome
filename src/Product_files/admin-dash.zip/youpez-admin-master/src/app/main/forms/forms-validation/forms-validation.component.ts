import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms-validation',
  templateUrl: './forms-validation.component.html',
  styleUrls: ['./forms-validation.component.css']
})
export class FormsValidationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
