import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing-simple',
  templateUrl: './pricing-simple.component.html',
  styleUrls: ['./pricing-simple.component.scss']
})
export class PricingSimpleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
