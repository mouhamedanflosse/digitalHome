import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-application-basic',
  templateUrl: './starter-application-basic.component.html',
  styleUrls: ['./starter-application-basic.component.scss']
})
export class StarterApplicationBasicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
