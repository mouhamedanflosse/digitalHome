import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-left-sidebar-basic',
  templateUrl: './starter-left-sidebar-basic.component.html',
  styleUrls: ['./starter-left-sidebar-basic.component.scss']
})
export class StarterLeftSidebarBasicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
