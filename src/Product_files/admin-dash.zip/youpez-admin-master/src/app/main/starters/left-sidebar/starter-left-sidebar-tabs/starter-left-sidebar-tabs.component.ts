import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-left-sidebar-tabs',
  templateUrl: './starter-left-sidebar-tabs.component.html',
  styleUrls: ['./starter-left-sidebar-tabs.component.scss']
})
export class StarterLeftSidebarTabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
