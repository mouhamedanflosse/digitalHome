import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-right-sidebar-header',
  templateUrl: './starter-right-sidebar-header.component.html',
  styleUrls: ['./starter-right-sidebar-header.component.scss']
})
export class StarterRightSidebarHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
