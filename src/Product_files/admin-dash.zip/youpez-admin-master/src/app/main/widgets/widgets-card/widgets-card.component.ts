import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widgets-card',
  templateUrl: './widgets-card.component.html',
  styleUrls: ['./widgets-card.component.css']
})
export class WidgetsCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
