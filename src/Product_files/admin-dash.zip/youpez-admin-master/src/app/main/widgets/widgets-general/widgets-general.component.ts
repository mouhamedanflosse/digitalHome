import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widgets-general',
  templateUrl: './widgets-general.component.html',
  styleUrls: ['./widgets-general.component.scss']
})
export class WidgetsGeneralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
